-- DROP TABLE lekcja;
-- DROP TABLE przedmiot;
-- DROP TABLE konto;
-- DROP TABLE uczen;
-- DROP TABLE klasa;
-- DROP TABLE korepetytor;


CREATE TABLE korepetytor (
  id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
  login VARCHAR(30) NOT NULL,
  haslo VARCHAR(30) NOT NULL,
  imie VARCHAR(30) NOT NULL,
  nazwisko VARCHAR(30) NOT NULL,
  czyAdministrator BIT NOT NULL
);

CREATE TABLE klasa (
  id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
  nazwa VARCHAR(30) NOT NULL,
  szkola VARCHAR(60),
  stopien VARCHAR(15)
);

CREATE TABLE uczen (
  id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
  imie VARCHAR(30) NOT NULL,
  nazwisko VARCHAR(50),
  idKlasy INT NOT NULL,
  FOREIGN KEY (idKlasy) REFERENCES klasa(id)
);

CREATE TABLE konto (
  id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
  idUcznia INT NOT NULL,
  czyBankowe BIT NOT NULL,
  FOREIGN KEY (idUcznia) REFERENCES uczen(id)
);


CREATE TABLE przedmiot (
  id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
  nazwa VARCHAR(30) NOT NULL
);

CREATE TABLE lekcja (
  id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
  temat VARCHAR(100),
  idPrzedmiotu INT NOT NULL,
  idUcznia INT NOT NULL,
  idKorepetytora INT NOT NULL,
  poczatek Datetime NOT NULL,
  czas int NOT NULL,
  czyZaplacona BIT,
  FOREIGN KEY (idUcznia) REFERENCES uczen(id),
  FOREIGN KEY (idKorepetytora) REFERENCES korepetytor(id),
  FOREIGN KEY (idPrzedmiotu) REFERENCES przedmiot(id)
);

INSERT INTO korepetytor (login, haslo,imie,nazwisko, czyAdministrator ) VALUES ("admin","123","Jan","Kowalski",1);

INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Martyna','Piekarska');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Weronika','Raniszewska');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Oliwia','Leśnik');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Wiktor','Drabczak');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Aleksandra','Górecka');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Agata','Zając');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Kacper','Klozak');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Angelika','Zwolińska');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Patryk','Rogowski');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Damian','Szymański');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Agnieszka','Karpińska');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Kamila','Rybka');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Julita','Durmowicz');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Karolina','Zielińska');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Kamil','Jabłoński');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Magdalena','Golasińska');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Klaudia','Kazimierska');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Adrian','Klonowski');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Kuba','Rusiecki');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Patrycja','Gawrońska');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Joanna','Kowalewska');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Julia','Majewska');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Lidia','Frankowska');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Łukasz','Walczak');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Agnieszka','Popielarek');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Sebastian','Harmasz');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Hanna','Kaczkowska');
INSERT INTO `uczen`(`imie`, `nazwisko`) VALUES ('Sandra','Krzemińska');